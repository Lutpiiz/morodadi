<?php
class Mservice extends CI_Model {

}