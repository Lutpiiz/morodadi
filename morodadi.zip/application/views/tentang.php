<div class="mb-5">
  <img src="<?php echo base_url('assets/_ (4).jpeg') ?>" alt="" width="100%" height="300px">
</div>